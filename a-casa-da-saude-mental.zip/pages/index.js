import PsicologiaApp from '../components/PsicologiaApp';
export default function Home() {
  return <PsicologiaApp />;
}