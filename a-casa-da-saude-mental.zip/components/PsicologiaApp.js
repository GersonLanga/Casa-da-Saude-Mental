import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import Image from "next/image";

export default function PsicologiaApp() {
  const [nome, setNome] = useState("");
  const [dataSessao, setDataSessao] = useState("");
  const [consultas, setConsultas] = useState([]);

  const marcarSessao = () => {
    if (nome && dataSessao) {
      setConsultas([...consultas, { nome, dataSessao }]);
      setNome("");
      setDataSessao("");
    }
  };

  const disturbios = [
    {
      titulo: "Depressão",
      descricao: "Transtorno de humor caracterizado por tristeza persistente e perda de interesse."
    },
    {
      titulo: "Ansiedade",
      descricao: "Distúrbio que causa preocupação e medo excessivos sem uma razão clara."
    },
    {
      titulo: "Transtorno Bipolar",
      descricao: "Alterações extremas de humor que variam de depressão a euforia."
    }
  ];

  return (
    <div className="p-6">
      <div className="flex items-center gap-4 mb-6">
        <Image src="/logo.png" alt="Logo" width={80} height={80} />
        <h1 className="text-3xl font-bold">A Casa da Saúde Mental</h1>
      </div>

      <Tabs defaultValue="marcar" className="w-full">
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="marcar">Marcar Consulta</TabsTrigger>
          <TabsTrigger value="info">Distúrbios Psicológicos</TabsTrigger>
        </TabsList>

        <TabsContent value="marcar">
          <Card className="mt-4">
            <CardContent className="grid gap-4 p-4">
              <h2 className="text-xl font-semibold">Marcar Sessão de Terapia</h2>
              <Input
                placeholder="Nome do paciente"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
              />
              <Input
                type="datetime-local"
                value={dataSessao}
                onChange={(e) => setDataSessao(e.target.value)}
              />
              <Button onClick={marcarSessao}>Marcar</Button>
            </CardContent>
          </Card>

          <div className="mt-6 grid gap-4">
            <h2 className="text-xl font-semibold">Sessões Marcadas</h2>
            {consultas.map((consulta, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <p><strong>Paciente:</strong> {consulta.nome}</p>
                  <p><strong>Data:</strong> {consulta.dataSessao}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="info">
          <div className="mt-4 grid gap-4">
            <h2 className="text-xl font-semibold">Informações sobre Distúrbios Psicológicos</h2>
            {disturbios.map((item, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg">{item.titulo}</h3>
                  <p>{item.descricao}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}